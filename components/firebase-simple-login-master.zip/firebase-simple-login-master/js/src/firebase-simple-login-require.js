// Pulled in by firebase-simple-login-local.js.  I used to inject this as an inline script, but IE would then
// execute it before the other scripts were loaded, so "goog" would be undefined.  So now it's
// in its own script.
goog.require('FirebaseSimpleLogin');